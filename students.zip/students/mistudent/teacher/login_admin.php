 



<!--  -->

<!DOCTYPE html>
<html>
<head>
    <title>Student Attendence</title>
    <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<!------ Include the above in your HEAD tag ---------->
    <link href="https://fonts.googleapis.com/css?family=Oleo+Script:400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Teko:400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/fontawesome.min.css" integrity="sha512-8jdwayz5n8F2cnW26l9vpV6+yGOcRAqz6HTu+DQ3FtVIAts2gTdlFZOGpYhvBMXkWEgxPN3Y22UWyZXuDowNLA==" crossorigin="anonymous" />
   <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/style.css">
	<style>
body{
  background-color: #e2e2f7;
}
</style>
</head>
<body>


<nav class="navbar navbar-dark bg-success">
    <a href="../index.php" class="navbar-brand"><i class="fas fa-list"></i>Home</a>
  </nav>


<div class="jumbotrom text-center" style="margin-bottom: 0">
	<h1 style="margin-top: 80px;"><b>page Teacher</b></h1>
</div>

<div class="container" style="margin-top: 125px;">
	<div class="row">
		<div class="col-md-4">
			c
		</div>
		<div class="col-md-4" style="margin-top: 20px;">
			<div class="card">
				<div class="card-header bg-warning text-black"><b>Login</b></div>
				<div id="message_admin"></div>
				<div class="card-body">
					<form method="post" id="login_form">
						
						<div class="form-group">
							<label>Email</label>
							<input type="email" name="t_email" id="t_email" class="form-control"/>
						</div>
						<div class="form-group">
							<label>Mot de passe</label>
							<input type="password" name="t_mdp" id="t_mdp" class="form-control"/>
						</div>
						<div class="form-group">
							<input type="submit" name="login" id="login" class="btn btn-warning" value="Login" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="forget_mdp.php">j'ai oublier mon mot de passe</a>
						</div>
					</form>
				</div>
			</div>
		</div>

		<div class="col-md-4">
			
		</div>

	</div>
</div>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
        <script src="https://kit.fontawesome.com/7cb0e7c261.js" crossorigin="anonymous"></script>

        
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="t_ajax.js"></script>
<script src="js/jquery.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

</body>
</html>